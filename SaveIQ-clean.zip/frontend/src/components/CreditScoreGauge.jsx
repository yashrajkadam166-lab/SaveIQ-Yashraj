import React from 'react';
import { getScoreCategoryDetails } from '../utils/formatters';
import { Info } from 'lucide-react';

export default function CreditScoreGauge({ score = 650 }) {
  const safeScore = Math.min(900, Math.max(300, Number(score) || 650));
  const details = getScoreCategoryDetails(safeScore);

  // Normalize score between 0% and 100% across the 300-900 CIBIL range
  const percentage = ((safeScore - 300) / 600) * 100;

  // Arc calculation for SVG semicircular gauge
  const radius = 80;
  const stroke = 14;
  const circumference = Math.PI * radius; // Half-circle
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm flex flex-col items-center justify-between relative">
      <div className="w-full flex items-center justify-between pb-2 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">
            Credit Score (CIBIL/Experian)
          </h3>
          <p className="text-xs text-slate-500">Standard Indian range 300 to 900</p>
        </div>
        <span className={`px-2.5 py-1 text-xs font-bold rounded-full ${details.badgeColor}`}>
          {details.category}
        </span>
      </div>

      {/* SVG Semicircle Gauge */}
      <div className="relative my-4 flex flex-col items-center">
        <svg width="220" height="130" viewBox="0 0 220 130" className="overflow-visible">
          <defs>
            <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#e11d48" />    {/* Poor: Rose */}
              <stop offset="25%" stopColor="#d97706" />   {/* Fair: Amber */}
              <stop offset="55%" stopColor="#2563eb" />   {/* Good: Blue */}
              <stop offset="80%" stopColor="#0d9488" />   {/* Very Good: Teal */}
              <stop offset="100%" stopColor="#059669" />  {/* Excellent: Emerald */}
            </linearGradient>
          </defs>

          {/* Background Track Arc */}
          <path
            d="M 30,120 A 80,80 0 0,1 190,120"
            fill="none"
            stroke="#e2e8f0"
            strokeWidth={stroke}
            strokeLinecap="round"
          />

          {/* Value Progress Arc */}
          <path
            d="M 30,120 A 80,80 0 0,1 190,120"
            fill="none"
            stroke="url(#scoreGradient)"
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Center Score Numbers */}
        <div className="absolute bottom-2 flex flex-col items-center">
          <span className="text-4xl font-extrabold text-slate-900 tracking-tight">
            {safeScore}
          </span>
          <span className="text-xs text-slate-400 font-medium">
            out of 900
          </span>
        </div>
      </div>

      {/* Brackets Indicator */}
      <div className="w-full grid grid-cols-5 text-center text-[10px] text-slate-500 font-medium pt-2 border-t border-slate-100">
        <div>
          <span className="block text-rose-600 font-bold">300-579</span>
          <span>Poor</span>
        </div>
        <div>
          <span className="block text-amber-600 font-bold">580-669</span>
          <span>Fair</span>
        </div>
        <div>
          <span className="block text-blue-600 font-bold">670-739</span>
          <span>Good</span>
        </div>
        <div>
          <span className="block text-teal-600 font-bold">740-799</span>
          <span>V. Good</span>
        </div>
        <div>
          <span className="block text-emerald-600 font-bold">800-900</span>
          <span>Excellent</span>
        </div>
      </div>

      {/* Advisory context */}
      <p className="mt-3 text-xs text-slate-600 text-center leading-relaxed bg-slate-50 p-2.5 rounded-xl w-full border border-slate-100">
        {details.advice}
      </p>

      {/* Legal & Educational Disclaimer */}
      <div className="mt-2 flex items-center gap-1.5 text-[10px] text-slate-400">
        <Info className="w-3 h-3 shrink-0" />
        <span>Educational benchmark. Categories are not guaranteed outcomes or formal credit advice.</span>
      </div>
    </div>
  );
}
