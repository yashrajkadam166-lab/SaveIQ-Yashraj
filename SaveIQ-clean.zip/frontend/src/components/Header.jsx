import React from 'react';
import { useAuth } from '../context/AuthContext';
import { User, LogOut, Sparkles, TrendingDown, HelpCircle } from 'lucide-react';

export default function Header({ onOpenDemoTour, onSimulateRepayment, isSimulating }) {
  const { user, isDemo, logout, loginAsDemo } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200 px-4 sm:px-6 py-3">
      <div className="flex items-center justify-between gap-4">
        {/* Left Side: Welcome greeting */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 font-bold text-sm shadow-inner">
            {user?.name ? user.name.charAt(0).toUpperCase() : 'U'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-slate-900 text-sm sm:text-base leading-tight">
                {user?.name || 'Rahul Sharma'}
              </h1>
              {isDemo && (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  <Sparkles className="w-2.5 h-2.5 text-emerald-600" />
                  Demo Mode
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 font-normal">
              {user?.email || 'rahul.sharma@example.com'} • Indian Rupee (₹)
            </p>
          </div>
        </div>

        {/* Right Side: Demo presentation walkthrough & Quick actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Simulate Repayment Action (Requirement #10 & #24) */}
          <button
            onClick={onSimulateRepayment}
            disabled={isSimulating}
            className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-50 text-teal-700 border border-teal-200 hover:bg-teal-100 hover:border-teal-300 transition-all shadow-sm active:scale-95 disabled:opacity-50"
            title="Simulate ₹1,00,000 debt part-payment to demonstrate instant DTI & score recalculation"
          >
            <TrendingDown className="w-3.5 h-3.5 text-teal-600" />
            <span>{isSimulating ? 'Recalculating...' : 'Simulate ₹1L Repayment'}</span>
          </button>

          {/* Guided Presentation Mode for Judges */}
          <button
            onClick={onOpenDemoTour}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm shadow-emerald-600/30 transition-all hover:-translate-y-0.5"
            title="Open guided walkthrough showing all 8 evaluation criteria"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Judges Presentation Mode</span>
            <span className="sm:hidden">Demo Guide</span>
          </button>

          {/* Sign Out */}
          <button
            onClick={logout}
            className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
