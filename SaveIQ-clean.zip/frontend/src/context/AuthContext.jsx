import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

const DEMO_USER_DEFAULT = {
  id: 'demo-rahul-sharma-id',
  name: 'Rahul Sharma',
  email: 'rahul.sharma@example.com'
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isDemo, setIsDemo] = useState(false);

  useEffect(() => {
    // Check saved session on load
    const token = localStorage.getItem('finhealth_token');
    const savedUser = localStorage.getItem('finhealth_user');

    if (token && savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        setIsDemo(parsed.email === DEMO_USER_DEFAULT.email || token === 'demo-token');
      } catch (e) {
        localStorage.removeItem('finhealth_token');
        localStorage.removeItem('finhealth_user');
      }
    } else {
      // Default to demo mode so user immediately has full interactive experience
      loginAsDemo(false);
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const res = await api.login({ email, password });
    if (res.success) {
      setUser(res.user);
      setIsDemo(Boolean(res.isDemo || res.user.email === DEMO_USER_DEFAULT.email));
      localStorage.setItem('finhealth_token', res.token);
      localStorage.setItem('finhealth_user', JSON.stringify(res.user));
    }
    return res;
  };

  const loginAsDemo = async (shouldReset = false) => {
    if (shouldReset) {
      try {
        await api.resetDemo();
      } catch (e) {
        console.warn('Reset demo error:', e);
      }
    }
    setUser(DEMO_USER_DEFAULT);
    setIsDemo(true);
    localStorage.setItem('finhealth_token', 'demo-token');
    localStorage.setItem('finhealth_user', JSON.stringify(DEMO_USER_DEFAULT));
  };

  const register = async (name, email, password, confirmPassword) => {
    const res = await api.register({ name, email, password, confirmPassword });
    if (res.success) {
      setUser(res.user);
      setIsDemo(false);
      localStorage.setItem('finhealth_token', res.token);
      localStorage.setItem('finhealth_user', JSON.stringify(res.user));
    }
    return res;
  };

  const logout = () => {
    setUser(null);
    setIsDemo(false);
    localStorage.removeItem('finhealth_token');
    localStorage.removeItem('finhealth_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isDemo,
        login,
        loginAsDemo,
        register,
        logout,
        isAuthenticated: Boolean(user)
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
