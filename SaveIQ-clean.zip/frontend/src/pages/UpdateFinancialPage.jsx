import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import DemoWalkthroughModal from '../components/DemoWalkthroughModal';
import { api } from '../services/api';
import { formatINR, formatCompactINR } from '../utils/formatters';
import { 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  TrendingDown, 
  TrendingUp, 
  CreditCard, 
  Wallet,
  Zap,
  Sparkles,
  ArrowDownRight,
  ArrowUpRight,
  Menu
} from 'lucide-react';

export default function UpdateFinancialPage() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showDemoTour, setShowDemoTour] = useState(false);

  // Original profile
  const [originalProfile, setOriginalProfile] = useState(null);

  // Form input state
  const [formData, setFormData] = useState({
    monthlyIncome: 60000,
    monthlyExpenses: 35000,
    totalDebt: 250000,
    monthlyEmi: 12000,
    creditLimit: 100000,
    creditCardOutstanding: 35000,
    creditScore: 650
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState('');
  const [lastUpdateRecord, setLastUpdateRecord] = useState(null);

  useEffect(() => {
    api.getDashboard().then((res) => {
      if (res.success && res.profile) {
        setOriginalProfile(res.profile);
        setFormData({
          monthlyIncome: res.profile.monthlyIncome || 60000,
          monthlyExpenses: res.profile.monthlyExpenses || 35000,
          totalDebt: res.profile.totalDebt || 250000,
          monthlyEmi: res.profile.monthlyEmi || 12000,
          creditLimit: res.profile.creditLimit || 100000,
          creditCardOutstanding: res.profile.creditCardOutstanding || 35000,
          creditScore: res.profile.creditScore || 650
        });
      }
    });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: Math.max(0, Number(value) || 0)
    }));
    if (error) setError('');
  };

  // 1-Click Scenario Preset: ₹1,00,000 Loan Pre-payment (Requirement #10 & #24)
  const applyPresetDebtRepayment = () => {
    setFormData((prev) => ({
      ...prev,
      totalDebt: Math.max(0, prev.totalDebt - 100000),
      monthlyEmi: Math.max(0, prev.monthlyEmi - 4000),
      creditScore: Math.min(900, prev.creditScore + 35)
    }));
  };

  // 1-Click Scenario: Clear Credit Card Balance
  const applyPresetClearCard = () => {
    setFormData((prev) => ({
      ...prev,
      creditCardOutstanding: 5000,
      creditScore: Math.min(900, prev.creditScore + 20)
    }));
  };

  // 1-Click Scenario: Salary Hike (+₹10,000)
  const applyPresetSalaryHike = () => {
    setFormData((prev) => ({
      ...prev,
      monthlyIncome: prev.monthlyIncome + 10000
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      const res = await api.updateFinancialProfile(formData, 'LOAN_REPAYMENT_UPDATE');
      if (res.success) {
        setSuccessMessage('Financial information updated successfully.');
        setLastUpdateRecord(res.updateRecord);
        setOriginalProfile(res.profile);
      } else {
        setError(res.message || 'Failed to update financial information.');
      }
    } catch (err) {
      setError(err.message || 'Something went wrong while saving your update.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Live client-side diff comparison
  const originalDebt = originalProfile?.totalDebt || 250000;
  const newDebt = formData.totalDebt;
  const debtDiff = originalDebt - newDebt;

  const originalDti = originalProfile?.dtiRatio || 20;
  const liveIncome = formData.monthlyIncome || 60000;
  const liveEmi = formData.monthlyEmi || 12000;
  const liveDti = liveIncome > 0 ? Number(((liveEmi / liveIncome) * 100).toFixed(1)) : 0;
  const dtiDiff = Number((originalDti - liveDti).toFixed(1));

  const originalUtil = originalProfile?.creditUtilization || 35;
  const liveLimit = formData.creditLimit || 100000;
  const liveCard = formData.creditCardOutstanding || 35000;
  const liveUtil = liveLimit > 0 ? Number(((liveCard / liveLimit) * 100).toFixed(1)) : 0;
  const utilDiff = Number((originalUtil - liveUtil).toFixed(1));

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col lg:pl-64 transition-all">
        {/* Mobile Header */}
        <div className="flex items-center justify-between lg:hidden px-4 py-2 bg-slate-900 text-white">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-extrabold text-sm tracking-tight">Update Financial Info</span>
          <div className="w-6" />
        </div>

        <Header onOpenDemoTour={() => setShowDemoTour(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto w-full">
          {/* Top Title Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  Update Financial Information
                </h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">
                  Real-Time Recalculation
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Log debt repayments, salary changes, or credit balance updates to instantly recalculate DTI and credit utilization.
              </p>
            </div>

            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs hover:bg-slate-200 transition-all"
            >
              <span>Back to Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Success Banner */}
          {successMessage && (
            <div className="p-4 rounded-2xl bg-emerald-600 text-white text-xs sm:text-sm font-bold flex items-center justify-between shadow-lg shadow-emerald-600/20 animate-in fade-in duration-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>{successMessage}</span>
              </div>
              <button
                onClick={() => navigate('/dashboard')}
                className="underline text-xs hover:text-emerald-100"
              >
                View Updated Dashboard &rarr;
              </button>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Quick 1-Click Simulation Buttons (Requirement #10 & #24) */}
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-3">
              Quick Simulation Presets (Click to Auto-fill):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={applyPresetDebtRepayment}
                className="p-3.5 rounded-2xl bg-teal-50 border border-teal-200 text-left hover:bg-teal-100 transition-all group"
              >
                <div className="flex items-center gap-2 text-teal-800 font-bold text-xs">
                  <TrendingDown className="w-4 h-4 text-teal-600" />
                  <span>Repay ₹1,00,000 Debt</span>
                </div>
                <p className="text-[11px] text-teal-700 mt-1">
                  Reduces total debt by ₹1 Lakh and lowers EMI burden.
                </p>
              </button>

              <button
                type="button"
                onClick={applyPresetClearCard}
                className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-left hover:bg-emerald-100 transition-all group"
              >
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  <span>Pay Down Credit Card</span>
                </div>
                <p className="text-[11px] text-emerald-700 mt-1">
                  Lowers card balance to ₹5,000 (5% utilization).
                </p>
              </button>

              <button
                type="button"
                onClick={applyPresetSalaryHike}
                className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 text-left hover:bg-blue-100 transition-all group"
              >
                <div className="flex items-center gap-2 text-blue-800 font-bold text-xs">
                  <TrendingUp className="w-4 h-4 text-blue-600" />
                  <span>Salary Hike (+₹10,000)</span>
                </div>
                <p className="text-[11px] text-blue-700 mt-1">
                  Increases gross income to ₹70,000/month.
                </p>
              </button>
            </div>
          </div>

          {/* Main Grid: Form + Live Before/After Comparison Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Form Column */}
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Outstanding Debt (₹)
                    </label>
                    <input
                      type="number"
                      name="totalDebt"
                      min="0"
                      value={formData.totalDebt}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      Currently: {formatINR(formData.totalDebt)}
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Monthly Loan EMI (₹)
                    </label>
                    <input
                      type="number"
                      name="monthlyEmi"
                      min="0"
                      value={formData.monthlyEmi}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">
                      Currently: {formatINR(formData.monthlyEmi)}/mo
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Credit Card Outstanding (₹)
                    </label>
                    <input
                      type="number"
                      name="creditCardOutstanding"
                      min="0"
                      value={formData.creditCardOutstanding}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Total Credit Limit (₹)
                    </label>
                    <input
                      type="number"
                      name="creditLimit"
                      min="0"
                      value={formData.creditLimit}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Monthly Income (₹)
                    </label>
                    <input
                      type="number"
                      name="monthlyIncome"
                      min="0"
                      value={formData.monthlyIncome}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Monthly Expenses (₹)
                    </label>
                    <input
                      type="number"
                      name="monthlyExpenses"
                      min="0"
                      value={formData.monthlyExpenses}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Credit Score (300-900)
                    </label>
                    <input
                      type="number"
                      name="creditScore"
                      min="300"
                      max="900"
                      value={formData.creditScore}
                      onChange={handleChange}
                      required
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 shadow-md shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSubmitting ? 'animate-spin' : ''}`} />
                  <span>{isSubmitting ? 'Recalculating & Saving...' : 'Save & Recalculate Metrics'}</span>
                </button>
              </form>
            </div>

            {/* Requirement #10: Real-Time Before/After Comparison Cards */}
            <div className="space-y-4">
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block pb-2 border-b border-slate-100">
                  Live Difference Indicators
                </span>

                {/* Outstanding Debt Diff */}
                <div className="my-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 block">Total Outstanding Debt</span>
                  <div className="mt-1 text-sm font-medium text-slate-700 flex items-center justify-between">
                    <span>{formatINR(originalDebt)} &rarr; {formatINR(newDebt)}</span>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-xs font-bold">
                    {debtDiff > 0 ? (
                      <span className="inline-flex items-center text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                        &darr; {formatINR(debtDiff)} Debt Reduction
                      </span>
                    ) : debtDiff < 0 ? (
                      <span className="inline-flex items-center text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                        <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                        &uarr; {formatINR(Math.abs(debtDiff))} Increased
                      </span>
                    ) : (
                      <span className="text-slate-400">No change</span>
                    )}
                  </div>
                </div>

                {/* DTI Ratio Diff */}
                <div className="my-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 block">Debt-to-Income (DTI)</span>
                  <div className="mt-1 text-sm font-medium text-slate-700 flex items-center justify-between">
                    <span>{originalDti}% &rarr; {liveDti}%</span>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-xs font-bold">
                    {dtiDiff > 0 ? (
                      <span className="inline-flex items-center text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                        &darr; {dtiDiff}% percentage points
                      </span>
                    ) : dtiDiff < 0 ? (
                      <span className="inline-flex items-center text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                        <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                        &uarr; {Math.abs(dtiDiff)}% percentage points
                      </span>
                    ) : (
                      <span className="text-slate-400">No change</span>
                    )}
                  </div>
                </div>

                {/* Credit Utilization Diff */}
                <div className="my-4 p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <span className="text-xs font-semibold text-slate-500 block">Credit Utilization</span>
                  <div className="mt-1 text-sm font-medium text-slate-700 flex items-center justify-between">
                    <span>{originalUtil}% &rarr; {liveUtil}%</span>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-xs font-bold">
                    {utilDiff > 0 ? (
                      <span className="inline-flex items-center text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                        &darr; {utilDiff}% percentage points
                      </span>
                    ) : utilDiff < 0 ? (
                      <span className="inline-flex items-center text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                        <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                        &uarr; {Math.abs(utilDiff)}% percentage points
                      </span>
                    ) : (
                      <span className="text-slate-400">No change</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      <DemoWalkthroughModal
        isOpen={showDemoTour}
        onClose={() => setShowDemoTour(false)}
      />
    </div>
  );
}
