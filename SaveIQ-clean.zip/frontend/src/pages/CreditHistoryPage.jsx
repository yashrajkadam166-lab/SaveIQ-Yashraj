import React, { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import CreditHistoryChart from '../components/CreditHistoryChart';
import DemoWalkthroughModal from '../components/DemoWalkthroughModal';
import { api } from '../services/api';
import { 
  TrendingUp, 
  Calendar, 
  PlusCircle, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Clock,
  Menu
} from 'lucide-react';

export default function CreditHistoryPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showDemoTour, setShowDemoTour] = useState(false);
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState(null);
  const [activeFilter, setActiveFilter] = useState('6m');
  const [loading, setLoading] = useState(true);

  // New Score logging modal or form state
  const [showLogForm, setShowLogForm] = useState(false);
  const [newScore, setNewScore] = useState(660);
  const [remarks, setRemarks] = useState('');
  const [logSuccess, setLogSuccess] = useState('');
  const [logError, setLogError] = useState('');

  const fetchHistory = async (filter = activeFilter) => {
    try {
      setLoading(true);
      const res = await api.getCreditHistory(filter);
      if (res.success) {
        setHistory(res.history);
        setStats(res.stats);
      }
    } catch (err) {
      console.error('Fetch history error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory(activeFilter);
  }, [activeFilter]);

  const handleFilterChange = (filterId) => {
    setActiveFilter(filterId);
    fetchHistory(filterId);
  };

  const handleLogScore = async (e) => {
    e.preventDefault();
    if (newScore < 300 || newScore > 900) {
      return setLogError('Score must be between 300 and 900.');
    }
    setLogError('');
    try {
      const res = await api.addCreditHistory(newScore, remarks || 'Quarterly Bureau Refresh');
      if (res.success) {
        setLogSuccess('New credit score point logged successfully!');
        setShowLogForm(false);
        setRemarks('');
        await fetchHistory(activeFilter);
        setTimeout(() => setLogSuccess(''), 5000);
      }
    } catch (err) {
      setLogError(err.message || 'Failed to record credit history entry.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col lg:pl-64 transition-all">
        {/* Mobile Header */}
        <div className="flex items-center justify-between lg:hidden px-4 py-2 bg-slate-900 text-white">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-extrabold text-sm tracking-tight">Credit History</span>
          <div className="w-6" />
        </div>

        <Header onOpenDemoTour={() => setShowDemoTour(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto w-full">
          {/* Top Title Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  Bureau Credit Score Progression
                </h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  CIBIL & Experian
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Visual analysis of credit score movements over time with timeline milestones and percentage trends.
              </p>
            </div>

            <button
              onClick={() => setShowLogForm(!showLogForm)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition-all shadow-sm"
            >
              <PlusCircle className="w-4 h-4 text-emerald-400" />
              <span>{showLogForm ? 'Close Form' : 'Log New Score Check'}</span>
            </button>
          </div>

          {logSuccess && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{logSuccess}</span>
            </div>
          )}

          {/* Collapsible Log New Score Form */}
          {showLogForm && (
            <div className="bg-white rounded-3xl p-6 border border-emerald-200 shadow-sm animate-in fade-in duration-200">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-emerald-600" />
                Record Verified Credit Score
              </h3>

              {logError && (
                <div className="mb-4 p-3 rounded-xl bg-rose-50 text-rose-700 text-xs">
                  {logError}
                </div>
              )}

              <form onSubmit={handleLogScore} className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Credit Score (300-900)
                  </label>
                  <input
                    type="number"
                    min="300"
                    max="900"
                    value={newScore}
                    onChange={(e) => setNewScore(Number(e.target.value))}
                    required
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Remarks / Bureau Note
                  </label>
                  <input
                    type="text"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="e.g. Paid off HDFC card"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm"
                  />
                </div>

                <div>
                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 shadow-sm"
                  >
                    Save Bureau Record
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Interactive Recharts Line / Area Chart */}
          <CreditHistoryChart
            history={history}
            onFilterChange={handleFilterChange}
            activeFilter={activeFilter}
            stats={stats}
          />

          {/* Historical Log Table */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500" />
              Verified Historical Bureau Log
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold uppercase">
                    <th className="pb-3 px-3">Date / Month</th>
                    <th className="pb-3 px-3">Recorded CIBIL Score</th>
                    <th className="pb-3 px-3">Category</th>
                    <th className="pb-3 px-3">Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {history.map((record) => (
                    <tr key={record.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-semibold text-slate-900">
                        {record.month || new Date(record.recordedAt).toLocaleString('en-IN', { month: 'short', year: 'numeric' })}
                      </td>
                      <td className="py-3 px-3 font-extrabold text-sm text-emerald-700">
                        {record.creditScore}
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                          {record.creditScore >= 740 ? 'Prime' : record.creditScore >= 670 ? 'Good' : 'Fair'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-500">
                        {record.remarks || 'Standard bureau assessment'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      <DemoWalkthroughModal
        isOpen={showDemoTour}
        onClose={() => setShowDemoTour(false)}
        onRefreshData={() => fetchHistory(activeFilter)}
      />
    </div>
  );
}
