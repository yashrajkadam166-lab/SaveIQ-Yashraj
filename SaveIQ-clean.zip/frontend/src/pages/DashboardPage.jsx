import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import MetricCard from '../components/MetricCard';
import CreditScoreGauge from '../components/CreditScoreGauge';
import CreditUtilizationChart from '../components/CreditUtilizationChart';
import DemoWalkthroughModal from '../components/DemoWalkthroughModal';
import { api } from '../services/api';
import { formatINR, formatCompactINR, getScoreCategoryDetails, getDtiCategoryDetails } from '../utils/formatters';
import { 
  Sparkles, 
  TrendingUp, 
  Wallet, 
  CreditCard, 
  ArrowRight, 
  ShieldCheck, 
  AlertCircle, 
  RefreshCw, 
  Activity, 
  CheckCircle2,
  TrendingDown,
  Clock,
  Layers,
  HelpCircle,
  Menu
} from 'lucide-react';

export default function DashboardPage() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showDemoTour, setShowDemoTour] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationSuccess, setSimulationSuccess] = useState('');

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await api.getDashboard();
      if (res.success) {
        if (!res.hasProfile) {
          // If no profile yet, direct to assessment
          navigate('/assessment');
          return;
        }
        setDashboardData(res);
      } else {
        setError(res.message || 'Failed to load dashboard data.');
      }
    } catch (err) {
      console.error('Fetch dashboard error:', err);
      setError('Failed to connect to backend service.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleSimulateRepayment = async () => {
    try {
      setIsSimulating(true);
      const res = await api.simulateRepayment();
      if (res.success) {
        setSimulationSuccess(res.message);
        await fetchDashboard();
        setTimeout(() => setSimulationSuccess(''), 7000);
      }
    } catch (err) {
      console.error('Simulation error:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  const profile = dashboardData?.profile || {};
  const creditDonut = dashboardData?.creditDonut || {
    usedCredit: profile.creditCardOutstanding || 35000,
    availableCredit: profile.availableCredit || 65000,
    totalLimit: profile.creditLimit || 100000,
    utilizationPercentage: profile.creditUtilization || 35
  };

  const scoreDetails = getScoreCategoryDetails(profile.creditScore || 650);
  const dtiDetails = getDtiCategoryDetails(profile.dtiRatio || 20);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar Navigation */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:pl-64 transition-all">
        {/* Top Header */}
        <div className="flex items-center justify-between lg:hidden px-4 py-2 bg-slate-900 text-white">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white"
          >
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-extrabold text-sm tracking-tight">FinHealth AI</span>
          <div className="w-6" />
        </div>

        <Header
          onOpenDemoTour={() => setShowDemoTour(true)}
          onSimulateRepayment={handleSimulateRepayment}
          isSimulating={isSimulating}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto w-full">
          {/* Notification / Toast Banner if simulated */}
          {simulationSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-500 text-white flex items-center justify-between shadow-lg shadow-emerald-500/20 animate-in fade-in slide-in-from-top-2 duration-300">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span className="text-xs sm:text-sm font-semibold">{simulationSuccess}</span>
              </div>
              <button
                onClick={() => setSimulationSuccess('')}
                className="text-white/80 hover:text-white text-xs font-bold px-2 py-1"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Quick Action Top Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Financial Health Overview
                </h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Live Sync
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Real-time metrics calculated from your income, credit commitments, and CIBIL score.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Link
                to="/ai-advisor"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs hover:from-emerald-700 hover:to-teal-700 shadow-md shadow-emerald-600/20 transition-all hover:-translate-y-0.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask AI Advisor</span>
              </Link>

              <Link
                to="/update-financial"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 shadow-sm transition-all"
              >
                <TrendingDown className="w-3.5 h-3.5 text-teal-600" />
                <span>Record Loan Repayment</span>
              </Link>
            </div>
          </div>

          {/* Requirement #4 & #12: 7 Dynamic Dashboard Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 1. Credit Score */}
            <MetricCard
              title="Credit Score"
              value={profile.creditScore || 650}
              subvalue="/ 900"
              category={scoreDetails.category}
              badgeColor={scoreDetails.badgeColor}
              icon={Activity}
              color="emerald"
              trendText="CIBIL / Experian"
            />

            {/* 2. Debt-to-Income (DTI) Ratio */}
            <MetricCard
              title="Debt-to-Income Ratio"
              value={`${profile.dtiRatio || 20}%`}
              category={dtiDetails.category}
              badgeColor={dtiDetails.color}
              icon={TrendingUp}
              color="teal"
              trendText="RBI Target: < 35%"
            />

            {/* 3. Credit Utilization */}
            <MetricCard
              title="Credit Utilization"
              value={`${profile.creditUtilization || 35}%`}
              category={profile.creditUtilization <= 30 ? 'Optimal (<30%)' : 'Exceeds 30%'}
              badgeColor={
                profile.creditUtilization <= 30
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-amber-50 text-amber-700 border border-amber-200'
              }
              icon={CreditCard}
              color="blue"
              trendText={`${formatINR(profile.creditCardOutstanding)} / ${formatINR(profile.creditLimit)}`}
            />

            {/* 4. Total Outstanding Debt */}
            <MetricCard
              title="Total Outstanding Debt"
              value={formatCompactINR(profile.totalDebt || 250000)}
              subvalue={formatINR(profile.totalDebt || 250000)}
              badgeText={`${profile.activeLoansCount || 2} Active Loans`}
              badgeColor="bg-slate-100 text-slate-700"
              icon={Wallet}
              color="amber"
              trendText={`Servicing: ${formatINR(profile.monthlyEmi)}/mo`}
            />
          </div>

          {/* Secondary 3 Metrics Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                  Monthly Gross Income
                </span>
                <span className="text-xl font-bold text-slate-900 mt-1 block">
                  {formatINR(profile.monthlyIncome || 60000)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 font-bold text-xs">
                Inflow
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                  Monthly Expenses
                </span>
                <span className="text-xl font-bold text-slate-900 mt-1 block">
                  {formatINR(profile.monthlyExpenses || 35000)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-100 text-slate-600 font-bold text-xs">
                Living Outflow
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
                  Monthly EMI Commitments
                </span>
                <span className="text-xl font-bold text-slate-900 mt-1 block">
                  {formatINR(profile.monthlyEmi || 12000)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 text-teal-600 font-bold text-xs">
                Debt Servicing
              </div>
            </div>
          </div>

          {/* Requirement #5 & #11: Visual Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Credit Score Semicircular Gauge */}
            <CreditScoreGauge score={profile.creditScore || 650} />

            {/* Credit Utilization Interactive Donut Chart */}
            <CreditUtilizationChart
              usedCredit={creditDonut.usedCredit}
              totalLimit={creditDonut.totalLimit}
              utilization={creditDonut.utilizationPercentage}
            />
          </div>

          {/* Financial Health Assessment Banner with Direct AI CTA */}
          <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-slate-950 p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="max-w-xl">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-semibold mb-3 border border-emerald-500/30">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Google Gemini Financial Analysis Ready</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                  Need a customized plan to reach the 750+ CIBIL bracket?
                </h3>
                <p className="mt-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Our AI advisor evaluates your DTI ratio ({profile.dtiRatio}%), credit card utilization ({profile.creditUtilization}%), and EMI load to generate an educational 5-step actionable recovery roadmap.
                </p>
              </div>

              <Link
                to="/ai-advisor"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-500 text-slate-950 font-extrabold text-sm hover:bg-emerald-400 shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 active:scale-95 shrink-0"
              >
                <span>Launch AI Advisory Consultation</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Recent Financial Updates Audit Trail */}
          {dashboardData?.recentUpdates && dashboardData.recentUpdates.length > 0 && (
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-600" />
                  Recent Recalculation Events & Audit Log
                </h3>
                <Link to="/update-financial" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700">
                  View Full Log &rarr;
                </Link>
              </div>

              <div className="divide-y divide-slate-100 mt-2">
                {dashboardData.recentUpdates.map((u) => (
                  <div key={u.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div>
                      <div className="font-bold text-slate-800">
                        {u.eventType ? u.eventType.replace(/_/g, ' ') : 'Financial Recalculation'}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {new Date(u.updatedAt).toLocaleString('en-IN')}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[11px]">
                        Debt: {formatINR(u.oldDebt)} &rarr; {formatINR(u.newDebt)}
                      </span>
                      {u.debtReduction > 0 && (
                        <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-bold text-[11px] border border-emerald-200">
                          &darr; {formatINR(u.debtReduction)}
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-semibold text-[11px]">
                        DTI: {u.oldDti}% &rarr; {u.newDti}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Guided Walkthrough Modal for Judges */}
      <DemoWalkthroughModal
        isOpen={showDemoTour}
        onClose={() => setShowDemoTour(false)}
        onRefreshData={fetchDashboard}
      />
    </div>
  );
}
