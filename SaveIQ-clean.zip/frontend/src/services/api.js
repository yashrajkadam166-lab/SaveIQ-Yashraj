/**
 * FinHealth AI - API Service Layer
 */

const API_BASE = '/api';

function getAuthHeaders() {
  const token = localStorage.getItem('finhealth_token') || 'demo-token';
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  };
}

async function request(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const headers = {
    ...getAuthHeaders(),
    ...(options.headers || {})
  };

  try {
    const res = await fetch(url, { ...options, headers });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || `Request failed with status ${res.status}`);
    }
    return data;
  } catch (err) {
    console.error(`API Error on ${endpoint}:`, err);
    throw err;
  }
}

export const api = {
  // Authentication
  async register(payload) {
    return request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async login(payload) {
    return request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async getProfile() {
    return request('/auth/profile');
  },

  // Financial Profile & Assessment
  async getFinancialProfile() {
    return request('/financial-profile');
  },

  async saveFinancialProfile(payload) {
    return request('/financial-profile', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async updateFinancialProfile(payload, eventType = 'FINANCIAL_UPDATE') {
    return request('/financial-profile', {
      method: 'PUT',
      body: JSON.stringify({ ...payload, eventType })
    });
  },

  async getFinancialUpdates() {
    return request('/financial-updates');
  },

  // Credit History
  async getCreditHistory(filter = 'all') {
    return request(`/credit-history?filter=${filter}`);
  },

  async addCreditHistory(creditScore, remarks) {
    return request('/credit-history', {
      method: 'POST',
      body: JSON.stringify({ creditScore, remarks })
    });
  },

  // AI Advisor
  async analyzeFinancialHealth(metrics) {
    return request('/ai/analyze', {
      method: 'POST',
      body: JSON.stringify(metrics || {})
    });
  },

  async getAIHistory() {
    return request('/ai/history');
  },

  // Dashboard & Demo controls
  async getDashboard() {
    return request('/dashboard');
  },

  async resetDemo() {
    return request('/demo/reset', { method: 'POST' });
  },

  async simulateRepayment() {
    return request('/demo/simulate-repayment', { method: 'POST' });
  }
};
