import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import financialRoutes from './routes/financial.js';
import creditRoutes from './routes/creditHistory.js';
import aiRoutes from './routes/ai.js';
import dashboardRoutes from './routes/dashboard.js';
import { isSupabaseConfigured } from './services/supabaseService.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Request logger for clarity
app.use((req, res, next) => {
  console.log(`[${new Date().toLocaleTimeString('en-IN')}] ${req.method} ${req.url}`);
  next();
});

// Routes mounting
app.use('/api/auth', authRoutes);
app.use('/api', financialRoutes);
app.use('/api', creditRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api', dashboardRoutes);

// System Health & Diagnostics
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'FinHealth AI API',
    supabaseConnected: isSupabaseConfigured,
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.length > 10)
  });
});

// Fallback 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `API endpoint '${req.originalUrl}' not found.`
  });
});

// Centralized error handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(500).json({
    success: false,
    message: 'An internal server error occurred. Please try again.'
  });
});

app.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`🚀 FinHealth AI Backend Server running on port ${PORT}`);
  console.log(`📊 Local API URL: http://localhost:${PORT}/api/health`);
  console.log(`🇮🇳 Indian Financial Rules & CIBIL 300-900 metrics active`);
  console.log(`======================================================\n`);
});
