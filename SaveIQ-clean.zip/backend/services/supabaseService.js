import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { store } from './store.js';

dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(
  supabaseUrl && 
  supabaseKey && 
  !supabaseUrl.includes('your-supabase-url') &&
  supabaseUrl.startsWith('https://')
);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseKey)
  : null;

if (isSupabaseConfigured) {
  console.log('✅ Supabase connected successfully to PostgreSQL cloud.');
} else {
  console.log('ℹ️ Supabase credentials not set or placeholder. Using resilient high-performance local store (Pre-seeded with Demo User Rahul Sharma).');
}

/**
 * Unified data access service
 */
export const dataService = {
  // Profiles
  async getProfile(userId) {
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single();
      if (!error && data) return data;
    }
    return store.findUserById(userId);
  },

  // Financial Profile
  async getFinancialProfile(userId) {
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.from('financial_profiles').select('*').eq('user_id', userId).single();
      if (!error && data) return data;
    }
    return store.getFinancialProfile(userId);
  },

  async saveFinancialProfile(userId, metrics) {
    if (isSupabaseConfigured) {
      try {
        const { data, error } = await supabase.from('financial_profiles').upsert({
          user_id: userId,
          credit_score: metrics.creditScore,
          monthly_income: metrics.monthlyIncome,
          monthly_expenses: metrics.monthlyExpenses,
          total_debt: metrics.totalDebt,
          monthly_emi: metrics.monthlyEmi,
          credit_limit: metrics.creditLimit,
          credit_card_outstanding: metrics.creditCardOutstanding,
          active_loans_count: metrics.activeLoansCount,
          credit_utilization: metrics.creditUtilization,
          dti_ratio: metrics.dtiRatio,
          updated_at: new Date().toISOString()
        }).select().single();
        if (!error && data) return data;
      } catch (err) {
        console.warn('Supabase save error, using local fallback:', err.message);
      }
    }
    return store.saveFinancialProfile(userId, metrics);
  },

  async updateFinancialProfile(userId, newData, eventType = 'FINANCIAL_UPDATE') {
    const result = store.updateFinancialProfile(userId, newData, eventType);

    if (isSupabaseConfigured) {
      try {
        await supabase.from('financial_profiles').upsert({
          user_id: userId,
          credit_score: result.profile.creditScore,
          monthly_income: result.profile.monthlyIncome,
          monthly_expenses: result.profile.monthlyExpenses,
          total_debt: result.profile.totalDebt,
          monthly_emi: result.profile.monthlyEmi,
          credit_limit: result.profile.creditLimit,
          credit_card_outstanding: result.profile.creditCardOutstanding,
          active_loans_count: result.profile.activeLoansCount,
          credit_utilization: result.profile.creditUtilization,
          dti_ratio: result.profile.dtiRatio,
          updated_at: new Date().toISOString()
        });

        await supabase.from('financial_updates').insert({
          user_id: userId,
          old_debt: result.updateRecord.oldDebt,
          new_debt: result.updateRecord.newDebt,
          old_dti: result.updateRecord.oldDti,
          new_dti: result.updateRecord.newDti,
          old_utilization: result.updateRecord.oldUtilization,
          new_utilization: result.updateRecord.newUtilization,
          old_score: result.updateRecord.oldScore,
          new_score: result.updateRecord.newScore,
          event_type: eventType
        });
      } catch (err) {
        console.warn('Supabase sync warning:', err.message);
      }
    }

    return result;
  },

  // Credit History
  async getCreditHistory(userId) {
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.from('credit_history').select('*').eq('user_id', userId).order('recorded_at', { ascending: true });
      if (!error && data && data.length > 0) return data;
    }
    return store.getCreditHistory(userId);
  },

  async addCreditHistory(userId, score, remarks) {
    if (isSupabaseConfigured) {
      try {
        await supabase.from('credit_history').insert({
          user_id: userId,
          credit_score: score,
          remarks
        });
      } catch (err) {
        console.warn('Supabase credit history insert warning:', err.message);
      }
    }
    return store.addCreditHistory(userId, score, remarks);
  },

  // Financial Updates Audit
  async getFinancialUpdates(userId) {
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.from('financial_updates').select('*').eq('user_id', userId).order('updated_at', { ascending: false });
      if (!error && data && data.length > 0) return data;
    }
    return store.getFinancialUpdates(userId);
  },

  // AI Consultations
  async saveAiConsultation(userId, snapshot, aiAnalysis, actionPlan) {
    if (isSupabaseConfigured) {
      try {
        await supabase.from('ai_consultations').insert({
          user_id: userId,
          financial_snapshot: snapshot,
          ai_analysis: aiAnalysis,
          action_plan: actionPlan
        });
      } catch (err) {
        console.warn('Supabase AI consultation save warning:', err.message);
      }
    }
    return store.saveAiConsultation(userId, snapshot, aiAnalysis, actionPlan);
  },

  async getAiConsultations(userId) {
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.from('ai_consultations').select('*').eq('user_id', userId).order('created_at', { ascending: false });
      if (!error && data && data.length > 0) return data;
    }
    return store.getAiConsultations(userId);
  }
};
