import { GoogleGenerativeAI } from '@google/generative-ai';
import dotenv from 'dotenv';
import { getCreditScoreCategory, getDtiCategory } from './store.js';

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;
let genAI = null;

if (apiKey && apiKey.trim().length > 10) {
  genAI = new GoogleGenerativeAI(apiKey.trim());
  console.log('🤖 Google Gemini API initialized with provided key.');
} else {
  console.log('ℹ️ GEMINI_API_KEY not set in backend/.env. Using intelligent rule-grounded Indian financial advisor simulation engine.');
}

/**
 * Intelligent fallback generator tailored strictly to Indian financial regulations (RBI guidelines, CIBIL)
 */
function generateStructuredFinancialAnalysis(metrics = {}) {
  const creditScore = Math.min(900, Math.max(300, Number(metrics.creditScore || 650)));
  const monthlyIncome = Math.max(0, Number(metrics.monthlyIncome || 0));
  const monthlyExpenses = Math.max(0, Number(metrics.monthlyExpenses || 0));
  const totalDebt = Math.max(0, Number(metrics.totalDebt || 0));
  const monthlyEmi = Math.max(0, Number(metrics.monthlyEmi || 0));
  const creditLimit = Math.max(0, Number(metrics.creditLimit || 0));
  const creditCardOutstanding = Math.max(0, Number(metrics.creditCardOutstanding || 0));
  const activeLoans = Math.max(0, Number(metrics.activeLoansCount || 1));

  const dtiRatio = monthlyIncome > 0 ? Number(((monthlyEmi / monthlyIncome) * 100).toFixed(1)) : 0;
  const creditUtilization = creditLimit > 0 ? Number(((creditCardOutstanding / creditLimit) * 100).toFixed(1)) : 0;
  const netSavings = Math.max(0, monthlyIncome - (monthlyExpenses + monthlyEmi));

  const scoreCatObj = getCreditScoreCategory(creditScore);
  const dtiCatObj = getDtiCategory(dtiRatio);
  const scoreCategory = scoreCatObj.category;
  const dtiCategory = dtiCatObj.category;

  // Calculate composite financial health score (0-100)
  // Factors: Credit score (35%), DTI (25%), Credit utilization (25%), Savings rate (15%)
  const scoreFactor = Math.min(100, Math.max(0, ((creditScore - 300) / 600) * 100)) * 0.35;
  const dtiFactor = Math.max(0, (1 - (dtiRatio / 50))) * 100 * 0.25;
  const utilFactor = Math.max(0, (1 - (creditUtilization / 60))) * 100 * 0.25;
  const savingsRate = monthlyIncome > 0 ? (netSavings / monthlyIncome) * 100 : 0;
  const savingsFactor = Math.min(100, Math.max(0, (savingsRate / 30) * 100)) * 0.15;
  
  const healthScore = Math.min(98, Math.max(35, Math.round(scoreFactor + dtiFactor + utilFactor + savingsFactor)));

  // Observations
  const keyObservations = [];
  const attentionAreas = [];

  if (creditUtilization > 30) {
    keyObservations.push(`Credit utilization is at ${creditUtilization}%, which exceeds the RBI-recommended threshold of 30%. Lowering this directly impacts your CIBIL score.`);
    attentionAreas.push('High credit card utilization (>30%)');
  } else {
    keyObservations.push(`Credit utilization is well-managed at ${creditUtilization}%, remaining safely within the healthy <30% guideline.`);
  }

  if (dtiRatio > 35) {
    keyObservations.push(`Debt-to-Income (DTI) ratio is ${dtiRatio}%, classified as "${dtiCategory}". Lenders prefer a DTI under 35% for approving favorable loan interest rates.`);
    attentionAreas.push('Elevated Debt-to-Income ratio');
  } else {
    keyObservations.push(`Your DTI ratio is healthy at ${dtiRatio}%, indicating sustainable monthly loan EMI commitments relative to your gross income.`);
  }

  if (creditScore < 670) {
    keyObservations.push(`Your credit score of ${creditScore} falls in the "${scoreCategory}" category. Target reaching 740+ for premium credit cards and lower home/auto loan spreads.`);
    attentionAreas.push('Credit score below prime tier (740+)');
  } else {
    keyObservations.push(`Credit score of ${creditScore} puts you in the "${scoreCategory}" band, eligible for competitive loan terms across Indian public & private banks.`);
  }

  if (savingsRate < 20) {
    attentionAreas.push('Monthly savings cushion is below 20% of net income');
  } else {
    keyObservations.push(`You retain approximately ₹${netSavings.toLocaleString('en-IN')}/month (${savingsRate.toFixed(1)}% savings rate) after living expenses and debt payments.`);
  }

  // 5-Step Action Plan
  const actionPlan = [
    {
      step: 1,
      title: 'Target Credit Card Utilization Under 30%',
      description: `Your current card balance is ₹${creditCardOutstanding.toLocaleString('en-IN')} out of ₹${creditLimit.toLocaleString('en-IN')}. Pay down ₹${Math.max(0, Math.round(creditCardOutstanding - (creditLimit * 0.25))).toLocaleString('en-IN')} before the statement billing cycle date to report sub-30% utilization to CIBIL & Experian.`,
      impact: 'High',
      timeframe: 'Immediate (Next billing cycle)'
    },
    {
      step: 2,
      title: 'Automate EMI & Bill Settlements via NACH / Auto-Debit',
      description: `Set up auto-debit or ECS mandates for your monthly EMI of ₹${monthlyEmi.toLocaleString('en-IN')} at least 3 days before due dates to avoid late payment penalties and derogatory 30-day DPD (Days Past Due) remarks on your credit report.`,
      impact: 'High',
      timeframe: 'Ongoing'
    },
    {
      step: 3,
      title: 'Optimize Monthly Discretionary Outflows',
      description: `With current monthly expenses at ₹${monthlyExpenses.toLocaleString('en-IN')}, audit recurring subscriptions and discretionary spending. Redirecting just ₹5,000/month towards principal pre-payments accelerates debt freedom.`,
      impact: 'Medium',
      timeframe: '1-2 months'
    },
    {
      step: 4,
      title: 'Establish a 3 to 6-Month Emergency Liquidity Buffer',
      description: `Target an emergency reserve of ₹${(monthlyExpenses * 3).toLocaleString('en-IN')} in high-liquidity Indian savings instruments (Sweep-in FDs or Overnight Debt Mutual Funds) to avoid relying on high-interest credit cards during medical or career emergencies.`,
      impact: 'High',
      timeframe: '3-6 months'
    },
    {
      step: 5,
      title: 'Track Credit-Score Progression & Monitor Report Errors',
      description: `Check your CIBIL / Experian report every quarter to verify that closed loans, updated balances, and PAN-linked credit facilities reflect accurately with zero duplicate accounts or fraudulent inquiries.`,
      impact: 'Medium',
      timeframe: 'Quarterly review'
    }
  ];

  return {
    healthScore,
    creditHealthCategory: scoreCategory,
    healthSummary: `Your overall financial health rating is ${healthScore}/100. With a monthly income of ₹${monthlyIncome.toLocaleString('en-IN')} and existing total debt of ₹${totalDebt.toLocaleString('en-IN')}, your financial framework is ${dtiRatio <= 35 ? 'resilient with manageable obligations' : 'facing elevated debt leverage'}. Following structured utilization and debt management will steadily elevate your credit profile into prime Indian banking tiers.`,
    keyObservations,
    creditHealth: {
      category: scoreCategory,
      creditUtilizationNote: `Used ₹${creditCardOutstanding.toLocaleString('en-IN')} of ₹${creditLimit.toLocaleString('en-IN')} (${creditUtilization}%). Ideal target is under 30%.`,
      debtLevelNote: `Total outstanding debt is ₹${totalDebt.toLocaleString('en-IN')} across active credit lines with ₹${monthlyEmi.toLocaleString('en-IN')} monthly servicing.`,
      dtiNote: `DTI ratio is ${dtiRatio}% (${dtiCategory}). Comfortably manageable when kept below 35%.`,
      attentionAreas: attentionAreas.length > 0 ? attentionAreas : ['Maintain continuous on-time payment track record']
    },
    actionPlan,
    disclaimer: 'AI-generated information is for educational purposes and should not replace professional financial advice. FinHealth AI will never ask for your passwords, OTPs, PINs, or bank account credentials.'
  };
}

export async function analyzeFinancialHealth(metrics = {}) {
  // If Gemini API is configured, attempt real AI generation
  if (genAI) {
    try {
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      
      const creditScore = Number(metrics.creditScore || 650);
      const monthlyIncome = Number(metrics.monthlyIncome || 0);
      const monthlyExpenses = Number(metrics.monthlyExpenses || 0);
      const totalDebt = Number(metrics.totalDebt || 0);
      const monthlyEmi = Number(metrics.monthlyEmi || 0);
      const creditLimit = Number(metrics.creditLimit || 0);
      const creditCardOutstanding = Number(metrics.creditCardOutstanding || 0);
      const creditUtilization = Number(metrics.creditUtilization || 0);
      const dtiRatio = Number(metrics.dtiRatio || 0);
      const activeLoansCount = Number(metrics.activeLoansCount || 1);
      const scoreCatObj = getCreditScoreCategory(creditScore);

      const prompt = `
You are a senior Indian personal finance and CIBIL credit score advisor for "FinHealth AI".
Analyze the user's financial profile tailored to Indian banking practices (RBI guidelines, CIBIL/Experian credit scores 300-900, Indian Rupee ₹ amounts):

User Data:
- Credit Score: ${creditScore} (Category: ${scoreCatObj.category})
- Gross Monthly Income: ₹${monthlyIncome.toLocaleString('en-IN')}
- Monthly Living Expenses: ₹${monthlyExpenses.toLocaleString('en-IN')}
- Total Outstanding Debt: ₹${totalDebt.toLocaleString('en-IN')}
- Monthly Loan EMI: ₹${monthlyEmi.toLocaleString('en-IN')}
- Total Credit Card Limit: ₹${creditLimit.toLocaleString('en-IN')}
- Credit Card Outstanding: ₹${creditCardOutstanding.toLocaleString('en-IN')}
- Credit Utilization: ${creditUtilization}%
- Debt-to-Income (DTI) Ratio: ${dtiRatio}%
- Active Loans: ${activeLoansCount}

CRITICAL RULES:
1. DO NOT guarantee future credit score numbers.
2. DO NOT promise loan approval.
3. DO NOT give misleading financial claims or pretend to be a commercial bank.
4. DO NOT ask for passwords, OTPs, card PINs or banking credentials.
5. All currency references must be in Indian Rupees (₹) with Indian numbering (e.g. ₹2,50,000).

Return ONLY valid JSON matching this exact structure:
{
  "healthScore": 75,
  "creditHealthCategory": "${scoreCatObj.category}",
  "healthSummary": "Clear, professional 2-3 sentence overview of their financial situation in Indian context.",
  "keyObservations": [
    "Observation 1 regarding credit utilization and RBI 30% rule",
    "Observation 2 regarding DTI ratio and EMI burden",
    "Observation 3 regarding credit score status"
  ],
  "creditHealth": {
    "category": "${scoreCatObj.category}",
    "creditUtilizationNote": "Analysis of their credit utilization",
    "debtLevelNote": "Analysis of their total debt level",
    "dtiNote": "Analysis of their DTI",
    "attentionAreas": ["Area 1 needing attention", "Area 2"]
  },
  "actionPlan": [
    { "step": 1, "title": "Step 1 title", "description": "Specific actionable recommendation with ₹ amounts", "impact": "High", "timeframe": "Immediate" },
    { "step": 2, "title": "Step 2 title", "description": "Specific actionable recommendation", "impact": "High", "timeframe": "Ongoing" },
    { "step": 3, "title": "Step 3 title", "description": "Specific actionable recommendation", "impact": "Medium", "timeframe": "1-2 months" },
    { "step": 4, "title": "Step 4 title", "description": "Specific actionable recommendation regarding emergency fund in FD/Liquid fund", "impact": "High", "timeframe": "3-6 months" },
    { "step": 5, "title": "Step 5 title", "description": "Specific actionable recommendation on CIBIL tracking", "impact": "Medium", "timeframe": "Quarterly" }
  ],
  "disclaimer": "AI-generated information is for educational purposes and should not replace professional financial advice. FinHealth AI will never ask for your passwords, OTPs, PINs, or bank account credentials."
}
`;

      const result = await model.generateContent({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0.3
        }
      });

      const responseText = result.response.text();
      const parsed = JSON.parse(responseText);
      return parsed;
    } catch (err) {
      console.warn('Gemini API call failed or timed out, using high-fidelity financial simulation engine:', err.message);
      return generateStructuredFinancialAnalysis(metrics);
    }
  }

  // Fallback to tailored Indian financial advisory engine
  return generateStructuredFinancialAnalysis(metrics);
}
