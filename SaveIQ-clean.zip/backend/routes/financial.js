import express from 'express';
import { authenticateUser } from '../middleware/auth.js';
import { dataService } from '../services/supabaseService.js';
import { calculateFinancialMetrics } from '../services/store.js';

const router = express.Router();

// Validation helper
function validateFinancialPayload(data) {
  const errors = [];
  const income = Number(data.monthlyIncome || 0);
  const expenses = Number(data.monthlyExpenses || 0);
  const debt = Number(data.totalDebt || 0);
  const emi = Number(data.monthlyEmi || 0);
  const limit = Number(data.creditLimit || 0);
  const cardOutstanding = Number(data.creditCardOutstanding || 0);
  const score = Number(data.creditScore || 650);

  if (isNaN(income) || income < 0) {
    errors.push('Monthly income cannot be negative.');
  }
  if (isNaN(expenses) || expenses < 0) {
    errors.push('Monthly expenses cannot be negative.');
  }
  if (isNaN(debt) || debt < 0) {
    errors.push('Total outstanding debt cannot be negative.');
  }
  if (isNaN(emi) || emi < 0) {
    errors.push('Monthly EMI cannot be negative.');
  }
  if (isNaN(limit) || limit < 0) {
    errors.push('Total credit limit cannot be negative.');
  }
  if (isNaN(cardOutstanding) || cardOutstanding < 0) {
    errors.push('Credit card outstanding cannot be negative.');
  }
  if (limit > 0 && cardOutstanding > limit * 1.5) {
    errors.push('Credit card balance cannot exceed 150% of the allocated credit limit.');
  }
  if (isNaN(score) || score < 300 || score > 900) {
    errors.push('Credit score must be between 300 and 900 (Indian CIBIL/Experian standard).');
  }

  return errors;
}

// GET /api/financial-profile
router.get('/financial-profile', authenticateUser, async (req, res) => {
  try {
    const profile = await dataService.getFinancialProfile(req.user.id);
    if (!profile) {
      return res.status(404).json({
        success: false,
        message: 'No financial profile found. Please complete the initial assessment.'
      });
    }
    return res.json({
      success: true,
      profile
    });
  } catch (err) {
    console.error('Fetch profile error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve financial profile.'
    });
  }
});

// POST /api/financial-profile (Initial Assessment)
router.post('/financial-profile', authenticateUser, async (req, res) => {
  try {
    const validationErrors = validateFinancialPayload(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).json({
        success: false,
        message: validationErrors[0],
        errors: validationErrors
      });
    }

    const calculated = calculateFinancialMetrics(req.body);
    const saved = await dataService.saveFinancialProfile(req.user.id, calculated);

    return res.status(201).json({
      success: true,
      message: 'Financial profile saved successfully! Metrics calculated.',
      profile: saved,
      metrics: calculated
    });
  } catch (err) {
    console.error('Save profile error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to save financial profile. Please try again.'
    });
  }
});

// PUT /api/financial-profile (Real-Time Financial Updates & Loan Repayments)
router.put('/financial-profile', authenticateUser, async (req, res) => {
  try {
    const validationErrors = validateFinancialPayload(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).json({
        success: false,
        message: validationErrors[0],
        errors: validationErrors
      });
    }

    const eventType = req.body.eventType || 'FINANCIAL_UPDATE';
    const result = await dataService.updateFinancialProfile(req.user.id, req.body, eventType);

    return res.json({
      success: true,
      message: 'Financial information updated successfully.',
      profile: result.profile,
      updateRecord: result.updateRecord
    });
  } catch (err) {
    console.error('Update profile error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to update financial profile. Please try again.'
    });
  }
});

// GET /api/financial-updates (Audit trail)
router.get('/financial-updates', authenticateUser, async (req, res) => {
  try {
    const updates = await dataService.getFinancialUpdates(req.user.id);
    return res.json({
      success: true,
      updates
    });
  } catch (err) {
    console.error('Fetch updates error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to load updates history.'
    });
  }
});

export default router;
