import express from 'express';
import { authenticateUser } from '../middleware/auth.js';
import { dataService } from '../services/supabaseService.js';

const router = express.Router();

// GET /api/credit-history
router.get('/credit-history', authenticateUser, async (req, res) => {
  try {
    const rawHistory = await dataService.getCreditHistory(req.user.id);
    const filter = (req.query.filter || 'all').toLowerCase(); // 3m, 6m, 1y, all

    let filtered = [...rawHistory];

    if (filter === '3m') {
      filtered = filtered.slice(-3);
    } else if (filter === '6m') {
      filtered = filtered.slice(-6);
    } else if (filter === '1y') {
      filtered = filtered.slice(-12);
    }

    // Compute progress stats
    const currentRecord = filtered[filtered.length - 1] || { creditScore: 650 };
    const previousRecord = filtered.length > 1 ? filtered[0] : currentRecord;

    const currentScore = currentRecord.creditScore;
    const previousScore = previousRecord.creditScore;
    const scoreChange = currentScore - previousScore;
    const percentageImprovement = previousScore > 0
      ? Number(((scoreChange / previousScore) * 100).toFixed(2))
      : 0;

    let trendDescription = 'Your credit score has remained steady.';
    if (scoreChange > 0) {
      trendDescription = `Positive upward momentum! Your score improved by ${scoreChange} points (${percentageImprovement > 0 ? '+' : ''}${percentageImprovement}%), reflecting consistent on-time payments and healthy debt discipline.`;
    } else if (scoreChange < 0) {
      trendDescription = `Your score dipped by ${Math.abs(scoreChange)} points. Review recent hard inquiries or elevated credit card balance reporting.`;
    }

    return res.json({
      success: true,
      history: filtered,
      fullCount: rawHistory.length,
      stats: {
        currentScore,
        previousScore,
        scoreChange,
        percentageImprovement,
        trendDescription,
        timeframe: filter
      }
    });
  } catch (err) {
    console.error('Credit history error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve credit history.'
    });
  }
});

// POST /api/credit-history
router.post('/credit-history', authenticateUser, async (req, res) => {
  try {
    const { creditScore, remarks } = req.body;
    const score = Number(creditScore);

    if (isNaN(score) || score < 300 || score > 900) {
      return res.status(400).json({
        success: false,
        message: 'Credit score must be between 300 and 900.'
      });
    }

    const record = await dataService.addCreditHistory(req.user.id, score, remarks || 'User logged score');

    return res.status(201).json({
      success: true,
      message: 'New credit score point recorded.',
      record
    });
  } catch (err) {
    console.error('Add credit history error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to record credit history entry.'
    });
  }
});

export default router;
