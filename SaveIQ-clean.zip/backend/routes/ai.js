import express from 'express';
import { authenticateUser } from '../middleware/auth.js';
import { dataService } from '../services/supabaseService.js';
import { analyzeFinancialHealth } from '../services/geminiService.js';
import { calculateFinancialMetrics } from '../services/store.js';

const router = express.Router();

// POST /api/ai/analyze
router.post('/analyze', authenticateUser, async (req, res) => {
  try {
    // Retrieve financial profile for user or take from body
    let metrics = req.body;
    if (!metrics || !metrics.monthlyIncome) {
      metrics = await dataService.getFinancialProfile(req.user.id);
    }

    if (!metrics) {
      metrics = calculateFinancialMetrics({});
    }

    // Run AI analysis (Gemini or tailored Indian advisory engine)
    const analysis = await analyzeFinancialHealth(metrics);

    // Save consultation record
    await dataService.saveAiConsultation(
      req.user.id,
      metrics,
      analysis,
      analysis.actionPlan
    );

    return res.json({
      success: true,
      message: 'AI Financial Analysis generated successfully.',
      analysis,
      metricsSnapshot: metrics
    });
  } catch (err) {
    console.error('AI analysis error:', err);
    return res.status(500).json({
      success: false,
      message: 'Something went wrong while generating the AI analysis. Please try again.'
    });
  }
});

// GET /api/ai/history
router.get('/history', authenticateUser, async (req, res) => {
  try {
    const consultations = await dataService.getAiConsultations(req.user.id);
    return res.json({
      success: true,
      consultations
    });
  } catch (err) {
    console.error('Fetch AI consultations error:', err);
    return res.status(500).json({
      success: false,
      message: 'Failed to load AI consultation history.'
    });
  }
});

export default router;
