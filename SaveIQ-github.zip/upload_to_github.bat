@echo off
setlocal enabledelayedexpansion
title Push Project to GitHub

echo ========================================================
echo             Push FinHealth to GitHub
echo ========================================================
echo.

set "GIT_EXE=C:\Users\HP\AppData\Local\GitHubDesktop\app-3.6.6\resources\app\git\cmd\git.exe"
if not exist "!GIT_EXE!" (
    where git >nul 2>nul
    if !errorlevel! equ 0 (
        set "GIT_EXE=git"
    ) else (
        echo [ERROR] Git was not found on your system!
        pause
        exit /b 1
    )
)

echo [1/3] Staging and committing changes...
"!GIT_EXE!" add -A
"!GIT_EXE!" commit -m "Update FinHealth project files" >nul 2>nul

echo [2/3] Checking branch...
"!GIT_EXE!" branch -M main

echo [3/3] Pushing to GitHub...
"!GIT_EXE!" push origin main

if !errorlevel! equ 0 (
    echo.
    echo ========================================================
    echo  SUCCESS! Your project has been pushed to GitHub!
    echo ========================================================
) else (
    echo.
    echo [NOTICE] If pushing to origin failed, check your network or credentials.
)

echo.
pause
